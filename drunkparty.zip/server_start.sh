screen -S node-server
cd /path/to/your/nodejs/app
node server.js
